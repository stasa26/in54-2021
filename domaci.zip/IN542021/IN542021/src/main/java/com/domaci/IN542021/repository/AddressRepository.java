package com.domaci.IN542021.repository;

import com.domaci.IN542021.entity.Address;
import com.domaci.IN542021.entity.Company;
import org.springframework.data.jpa.repository.JpaRepository;

public interface AddressRepository extends JpaRepository<Address, Long> {
}
