package com.domaci.IN542021.repository;

import com.domaci.IN542021.entity.Company;
import org.springframework.data.jpa.repository.JpaRepository;

public interface CompanyRepository extends JpaRepository<Company, Long> {
}
