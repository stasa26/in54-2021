package com.domaci.IN542021.repository;

import com.domaci.IN542021.entity.Department;
import org.springframework.data.jpa.repository.JpaRepository;

public interface DepartmentRepository extends JpaRepository<Department, Long> {
}
