package com.domaci.IN542021.repository;

import com.domaci.IN542021.entity.Project;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ProjectRepository extends JpaRepository<Project, Long> {
}
