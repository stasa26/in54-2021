package com.domaci.IN542021;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class In542021ApplicationTests {

	@Test
	void contextLoads() {
	}

}
